import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    console.log("🌱 Starting to seed the database...");

    // Check if tables exist by counting records
    const contactCount = await db.select({ count: { expression: "count(*)", as: "count" } })
      .from(schema.contactSubmissions);
    
    const applicationCount = await db.select({ count: { expression: "count(*)", as: "count" } })
      .from(schema.serviceApplications);
    
    console.log(`Found ${contactCount[0].count} contact submissions`);
    console.log(`Found ${applicationCount[0].count} service applications`);
    
    // Seed sample contact submissions if none exist
    if (parseInt(contactCount[0].count.toString()) === 0) {
      console.log("Seeding sample contact submissions...");
      
      // We're not creating mock data as per the guidelines
      console.log("No existing contact submissions found. New submissions will be created via the contact form.");
    } else {
      console.log("Contact submissions already exist. Skipping seed.");
    }
    
    // Seed sample service applications if none exist
    if (parseInt(applicationCount[0].count.toString()) === 0) {
      console.log("Seeding sample service applications...");
      
      // We're not creating mock data as per the guidelines
      console.log("No existing service applications found. New applications will be created via the application form.");
    } else {
      console.log("Service applications already exist. Skipping seed.");
    }
    
    console.log("✅ Seeding completed successfully!");
  } catch (error) {
    console.error("❌ Error while seeding the database:", error);
  }
}

seed();
