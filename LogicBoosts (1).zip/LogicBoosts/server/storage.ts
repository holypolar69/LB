import { db } from "@db";
import { 
  contactSubmissions, 
  serviceApplications,
  type InsertContact,
  type InsertApplication
} from "@shared/schema";

export const storage = {
  // Contact form submissions
  async insertContactSubmission(contactData: InsertContact) {
    const [newContact] = await db.insert(contactSubmissions)
      .values(contactData)
      .returning();
    
    return newContact;
  },
  
  async getContactSubmissions() {
    return await db.query.contactSubmissions.findMany({
      orderBy: (contactSubmissions, { desc }) => [desc(contactSubmissions.createdAt)]
    });
  },
  
  async updateContactSubmissionStatus(id: number, responded: boolean) {
    const [updatedContact] = await db.update(contactSubmissions)
      .set({ responded })
      .where((contactSubmissions, { eq }) => eq(contactSubmissions.id, id))
      .returning();
    
    return updatedContact;
  },
  
  // Service applications
  async insertServiceApplication(applicationData: InsertApplication) {
    const [newApplication] = await db.insert(serviceApplications)
      .values(applicationData)
      .returning();
    
    return newApplication;
  },
  
  async getServiceApplications() {
    return await db.query.serviceApplications.findMany({
      orderBy: (serviceApplications, { desc }) => [desc(serviceApplications.createdAt)]
    });
  },
  
  async getServiceApplicationById(id: number) {
    return await db.query.serviceApplications.findFirst({
      where: (serviceApplications, { eq }) => eq(serviceApplications.id, id)
    });
  },
  
  async updateServiceApplicationStatus(id: number, status: string) {
    const [updatedApplication] = await db.update(serviceApplications)
      .set({ 
        status,
        updatedAt: new Date()
      })
      .where((serviceApplications, { eq }) => eq(serviceApplications.id, id))
      .returning();
    
    return updatedApplication;
  }
};
