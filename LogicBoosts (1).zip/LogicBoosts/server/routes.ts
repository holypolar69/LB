import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema, insertApplicationSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiPrefix = '/api';
  
  // Contact form submission endpoint
  app.post(`${apiPrefix}/contact`, async (req, res) => {
    try {
      // Validate the request body
      const validatedData = insertContactSchema.parse(req.body);
      
      // Insert the contact submission into the database
      const newContact = await storage.insertContactSubmission(validatedData);
      
      return res.status(201).json({
        success: true,
        message: "Contact form submitted successfully",
        data: newContact
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false,
          message: "Validation error", 
          errors: error.errors 
        });
      }
      
      console.error("Error submitting contact form:", error);
      return res.status(500).json({ 
        success: false,
        message: "An error occurred while submitting your message. Please try again." 
      });
    }
  });
  
  // Service application submission endpoint
  app.post(`${apiPrefix}/applications`, async (req, res) => {
    try {
      // Validate the request body
      const validatedData = insertApplicationSchema.parse(req.body);
      
      // Insert the application into the database
      const newApplication = await storage.insertServiceApplication(validatedData);
      
      return res.status(201).json({
        success: true,
        message: "Application submitted successfully",
        data: newApplication
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false,
          message: "Validation error", 
          errors: error.errors 
        });
      }
      
      console.error("Error submitting application:", error);
      return res.status(500).json({ 
        success: false,
        message: "An error occurred while submitting your application. Please try again." 
      });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
