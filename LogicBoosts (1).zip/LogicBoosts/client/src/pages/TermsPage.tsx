import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const TermsPage = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | LogicBoosts</title>
        <meta name="description" content="Terms of Service for LogicBoosts. Read our terms and conditions for using our services." />
      </Helmet>
      <main>
        <section className="gradient-bg text-white py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-6"
            >
              Terms of Service
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl max-w-3xl mx-auto"
            >
              Last Updated: May 5, 2025
            </motion.p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8 max-w-4xl">
            <div className="prose prose-lg max-w-none">
              <h2>1. Acceptance of Terms</h2>
              <p>
                By accessing or using the services provided by LogicBoosts ("we," "us," or "our"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.
              </p>

              <h2>2. Description of Services</h2>
              <p>
                LogicBoosts provides digital marketing, web development, and business growth strategy services. The specific services to be provided will be detailed in separate agreements or statements of work between LogicBoosts and the client.
              </p>

              <h2>3. Service Fees and Payment</h2>
              <p>
                Fees for our services are outlined on our Pricing page and/or in client-specific proposals and agreements. Payment terms will be specified in these documents.
              </p>
              <p>
                Unless otherwise stated, all fees are quoted in US Dollars and are non-refundable. We reserve the right to change our fees with reasonable notice.
              </p>

              <h2>4. Client Responsibilities</h2>
              <p>
                Clients are responsible for:
              </p>
              <ul>
                <li>Providing accurate and complete information as required for the provision of services</li>
                <li>Responding to requests for approvals or information in a timely manner</li>
                <li>Using the services in compliance with all applicable laws and regulations</li>
                <li>Maintaining the confidentiality of any account credentials provided</li>
              </ul>

              <h2>5. Intellectual Property Rights</h2>
              <p>
                Upon full payment for services, clients will own the deliverables specifically created for them, excluding:
              </p>
              <ul>
                <li>Our proprietary tools, processes, and methodologies</li>
                <li>Third-party materials used with appropriate licenses</li>
                <li>General knowledge, skills, and experience that we may develop or use in the course of providing services</li>
              </ul>
              <p>
                We retain the right to display and link to your project as part of our portfolio and to write about the project in articles, books, or other media.
              </p>

              <h2>6. Confidentiality</h2>
              <p>
                We will treat client information as confidential and will not disclose it to third parties except as required to provide our services or as required by law.
              </p>

              <h2>7. Limitation of Liability</h2>
              <p>
                To the maximum extent permitted by law, LogicBoosts shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of or inability to use our services.
              </p>
              <p>
                Our total liability for any claims under these terms shall not exceed the amount paid by you for the services directly related to the claim.
              </p>

              <h2>8. Service Availability and Modifications</h2>
              <p>
                We strive to provide uninterrupted services but cannot guarantee that services will be available at all times. We reserve the right to modify, suspend, or discontinue any part of our services with or without notice.
              </p>

              <h2>9. Term and Termination</h2>
              <p>
                The term of service will be specified in your agreement with us. Either party may terminate the agreement according to the terms specified therein.
              </p>
              <p>
                Upon termination, you will remain liable for all fees incurred up to the date of termination.
              </p>

              <h2>10. Governing Law</h2>
              <p>
                These Terms of Service shall be governed by and construed in accordance with the laws of the State of Minnesota, without regard to its conflict of law provisions.
              </p>

              <h2>11. Changes to Terms</h2>
              <p>
                We reserve the right to modify these Terms of Service at any time. We will provide notice of significant changes by posting the updated terms on our website. Your continued use of our services after such changes constitutes your acceptance of the new terms.
              </p>

              <h2>12. Contact Information</h2>
              <p>
                If you have any questions about these Terms of Service, please contact us via Instagram @logicboosts.
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default TermsPage;