import React from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useApplication } from '@/context/ApplicationContext';
import { Check, ChevronRight, User, Briefcase, Settings, FileText } from 'lucide-react';

const SubmitPage = () => {
  const [, setLocation] = useLocation();
  const { formValues, submitApplication, isPending } = useApplication();

  const handleSubmit = () => {
    submitApplication();
  };

  const servicesMap = {
    digital_marketing: "Digital Marketing",
    web_development: "Web Development",
    data_analytics: "Data Analytics", 
    crm_implementation: "CRM Implementation",
    brand_strategy: "Brand Strategy",
    growth_consulting: "Growth Consulting",
    content_creation: "Content Creation"
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="container max-w-4xl py-12"
    >
      <Card className="border-2 border-primary/10 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-t-lg">
          <CardTitle className="text-2xl md:text-3xl text-primary font-bold">Review Application</CardTitle>
          <CardDescription>
            Step 5 of 5: Review your application before submitting
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-8 px-6 space-y-6">
          <div>
            <div className="flex items-center mb-4">
              <User className="text-primary mr-2" size={20} />
              <h3 className="text-lg font-semibold">Personal Information</h3>
              <Button
                variant="ghost"
                size="sm"
                className="ml-auto text-primary"
                onClick={() => setLocation('/apply/personal')}
              >
                Edit <ChevronRight className="ml-1" size={16} />
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
              <div>
                <div className="text-sm text-muted-foreground">Full Name</div>
                <div className="font-medium">{formValues.fullName}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Email</div>
                <div className="font-medium">{formValues.email}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Phone</div>
                <div className="font-medium">{formValues.phone}</div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <div className="flex items-center mb-4">
              <Briefcase className="text-primary mr-2" size={20} />
              <h3 className="text-lg font-semibold">Business Information</h3>
              <Button
                variant="ghost"
                size="sm"
                className="ml-auto text-primary"
                onClick={() => setLocation('/apply/business')}
              >
                Edit <ChevronRight className="ml-1" size={16} />
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
              <div>
                <div className="text-sm text-muted-foreground">Company Name</div>
                <div className="font-medium">{formValues.companyName}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Website</div>
                <div className="font-medium">{formValues.website || "Not provided"}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Industry</div>
                <div className="font-medium">{formValues.industry}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Company Size</div>
                <div className="font-medium">{formValues.companySize}</div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <div className="flex items-center mb-4">
              <Settings className="text-primary mr-2" size={20} />
              <h3 className="text-lg font-semibold">Services & Budget</h3>
              <Button
                variant="ghost"
                size="sm"
                className="ml-auto text-primary"
                onClick={() => setLocation('/apply/services')}
              >
                Edit <ChevronRight className="ml-1" size={16} />
              </Button>
            </div>
            <div className="pl-7 mb-4">
              <div className="text-sm text-muted-foreground mb-2">Selected Services</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {formValues.services.map((service) => (
                  <div key={service} className="flex items-center">
                    <Check className="text-primary mr-2" size={16} />
                    <span>{servicesMap[service as keyof typeof servicesMap]}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-7">
              <div>
                <div className="text-sm text-muted-foreground">Budget Range</div>
                <div className="font-medium">{formValues.budget}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Timeline</div>
                <div className="font-medium">{formValues.timeline}</div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <div className="flex items-center mb-4">
              <FileText className="text-primary mr-2" size={20} />
              <h3 className="text-lg font-semibold">Project Details</h3>
              <Button
                variant="ghost"
                size="sm"
                className="ml-auto text-primary"
                onClick={() => setLocation('/apply/project')}
              >
                Edit <ChevronRight className="ml-1" size={16} />
              </Button>
            </div>
            <div className="space-y-4 pl-7">
              <div>
                <div className="text-sm text-muted-foreground">Project Description</div>
                <div className="font-medium whitespace-pre-line">{formValues.projectDescription}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Project Goals</div>
                <div className="font-medium whitespace-pre-line">{formValues.goals}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Current Challenges</div>
                <div className="font-medium whitespace-pre-line">{formValues.challenges}</div>
              </div>
            </div>
          </div>

          <Separator />

          <div className="flex justify-between pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setLocation('/apply/project')}
            >
              Back
            </Button>
            <Button
              onClick={handleSubmit}
              className="bg-gradient-to-r from-primary to-secondary text-white"
              disabled={isPending}
            >
              {isPending ? 'Submitting...' : 'Submit Application'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default SubmitPage;