import React from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useApplication, FormValues } from '@/context/ApplicationContext';

const projectSchema = z.object({
  projectDescription: z.string().min(10, "Please describe your project in more detail"),
  goals: z.string().min(10, "Please describe your goals in more detail"),
  challenges: z.string().min(10, "Please describe your challenges in more detail")
});

type ProjectFormValues = Pick<FormValues, 'projectDescription' | 'goals' | 'challenges'>;

const ProjectPage = () => {
  const [, setLocation] = useLocation();
  const { formValues, updateFormValues } = useApplication();
  
  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      projectDescription: formValues.projectDescription,
      goals: formValues.goals,
      challenges: formValues.challenges
    }
  });

  const onSubmit = (data: ProjectFormValues) => {
    updateFormValues(data);
    setLocation('/apply/submit');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="container max-w-4xl py-12"
    >
      <Card className="border-2 border-primary/10 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-t-lg">
          <CardTitle className="text-2xl md:text-3xl text-primary font-bold">Project Details</CardTitle>
          <CardDescription>
            Step 4 of 5: Tell us about your project goals and challenges
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-8 px-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="projectDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe your project and what you're looking to achieve..." 
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="goals"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Goals</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="What specific goals are you trying to achieve with this project? What metrics would you use to measure success?" 
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="challenges"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Challenges</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="What challenges are you currently facing that you hope to solve with our services?" 
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation('/apply/services')}
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-primary to-secondary text-white"
                >
                  Review Application
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectPage;