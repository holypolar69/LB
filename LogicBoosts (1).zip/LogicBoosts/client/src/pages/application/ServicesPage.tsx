import React from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useApplication, FormValues } from '@/context/ApplicationContext';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { BarChart3, Database, Globe, Search, MessageSquare, Rocket, TrendingUp } from 'lucide-react';

const servicesSchema = z.object({
  services: z.array(z.string()).min(1, "Please select at least one service"),
  budget: z.string().min(1, "Please select a budget range"),
  timeline: z.string().min(1, "Please select a timeline")
});

type ServicesFormValues = Pick<FormValues, 'services' | 'budget' | 'timeline'>;

// Services offered by LogicBoosts
const serviceOptions = [
  {
    id: "digital_marketing",
    label: "Digital Marketing",
    description: "SEO, PPC, Social Media, Content Marketing",
    icon: <Search className="h-5 w-5" />
  },
  {
    id: "web_development",
    label: "Web Development",
    description: "Website Design, E-commerce, Web Applications",
    icon: <Globe className="h-5 w-5" />
  },
  {
    id: "data_analytics",
    label: "Data Analytics",
    description: "Business Intelligence, Data Visualization, Reports",
    icon: <BarChart3 className="h-5 w-5" />
  },
  {
    id: "crm_implementation",
    label: "CRM Implementation",
    description: "Customer Relationship Management Solutions",
    icon: <Database className="h-5 w-5" />
  },
  {
    id: "brand_strategy",
    label: "Brand Strategy",
    description: "Brand Identity, Positioning, Messaging",
    icon: <Rocket className="h-5 w-5" />
  },
  {
    id: "growth_consulting",
    label: "Growth Consulting",
    description: "Market Analysis, Business Strategy, Scaling Plans",
    icon: <TrendingUp className="h-5 w-5" />
  },
  {
    id: "content_creation",
    label: "Content Creation",
    description: "Blogs, Videos, Infographics, Social Media Content",
    icon: <MessageSquare className="h-5 w-5" />
  }
];

const budgetOptions = [
  "$5,000 - $10,000",
  "$10,000 - $25,000",
  "$25,000 - $50,000",
  "$50,000 - $100,000",
  "$100,000+"
];

const timelineOptions = [
  "Less than 1 month",
  "1-3 months",
  "3-6 months",
  "6-12 months",
  "12+ months"
];

const ServicesPage = () => {
  const [, setLocation] = useLocation();
  const { formValues, updateFormValues } = useApplication();
  
  const form = useForm<ServicesFormValues>({
    resolver: zodResolver(servicesSchema),
    defaultValues: {
      services: formValues.services,
      budget: formValues.budget,
      timeline: formValues.timeline
    }
  });

  const onSubmit = (data: ServicesFormValues) => {
    updateFormValues(data);
    setLocation('/apply/project');
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="container max-w-4xl py-12"
    >
      <Card className="border-2 border-primary/10 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-t-lg">
          <CardTitle className="text-2xl md:text-3xl text-primary font-bold">Services</CardTitle>
          <CardDescription>
            Step 3 of 5: Select the services you're interested in
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-8 px-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="services"
                render={() => (
                  <FormItem>
                    <div className="mb-4">
                      <FormLabel className="text-base font-medium">Services</FormLabel>
                      <div className="text-sm text-muted-foreground mb-4">
                        Select the services that you're interested in
                      </div>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {serviceOptions.map((service) => (
                        <FormField
                          key={service.id}
                          control={form.control}
                          name="services"
                          render={({ field }) => {
                            return (
                              <FormItem
                                key={service.id}
                                className="flex flex-row items-start space-x-3 space-y-0 border rounded-lg p-4 hover:bg-muted/50 transition-colors"
                              >
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes(service.id)}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, service.id])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== service.id
                                            )
                                          )
                                    }}
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <div className="flex items-center">
                                    <span className="mr-2 text-primary">{service.icon}</span>
                                    <FormLabel className="font-semibold">
                                      {service.label}
                                    </FormLabel>
                                  </div>
                                  <div className="text-[13px] text-muted-foreground">
                                    {service.description}
                                  </div>
                                </div>
                              </FormItem>
                            )
                          }}
                        />
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="budget"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Budget Range</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select budget range" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {budgetOptions.map((budget) => (
                            <SelectItem key={budget} value={budget}>
                              {budget}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="timeline"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project Timeline</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select timeline" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {timelineOptions.map((timeline) => (
                            <SelectItem key={timeline} value={timeline}>
                              {timeline}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation('/apply/business')}
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-primary to-secondary text-white"
                >
                  Next Step
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ServicesPage;