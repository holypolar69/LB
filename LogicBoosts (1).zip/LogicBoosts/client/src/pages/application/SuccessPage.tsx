import React from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, ArrowRight } from 'lucide-react';

const SuccessPage = () => {
  const [, setLocation] = useLocation();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="container max-w-4xl py-12"
    >
      <Card className="border-2 border-primary/10 shadow-lg text-center">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-t-lg pb-6">
          <div className="flex justify-center mb-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ 
                type: "spring", 
                stiffness: 260, 
                damping: 20,
                delay: 0.1
              }}
              className="rounded-full bg-primary/10 p-3"
            >
              <CheckCircle2 className="h-16 w-16 text-primary" />
            </motion.div>
          </div>
          <CardTitle className="text-2xl md:text-3xl text-primary font-bold">Application Submitted!</CardTitle>
          <CardDescription className="text-lg">
            Thank you for your interest in LogicBoosts
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-8 px-6 space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="max-w-md mx-auto"
          >
            <p className="text-muted-foreground mb-6">
              We've received your application and will review it promptly. One of our team members will be in touch with you within 1-2 business days to discuss your project in more detail.
            </p>
            
            <div className="bg-primary/5 rounded-lg p-4 mb-8">
              <h3 className="font-medium text-primary mb-2">What happens next?</h3>
              <ul className="text-left text-sm space-y-2">
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-5 w-5 bg-primary/20 rounded-full flex items-center justify-center text-primary text-xs mr-2 mt-0.5">1</span>
                  <span>Our team will review your application</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-5 w-5 bg-primary/20 rounded-full flex items-center justify-center text-primary text-xs mr-2 mt-0.5">2</span>
                  <span>We'll reach out to schedule an initial consultation</span>
                </li>
                <li className="flex items-start">
                  <span className="flex-shrink-0 h-5 w-5 bg-primary/20 rounded-full flex items-center justify-center text-primary text-xs mr-2 mt-0.5">3</span>
                  <span>We'll develop a tailored proposal for your specific needs</span>
                </li>
              </ul>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                variant="outline"
                onClick={() => setLocation('/')}
                className="flex-1"
              >
                Return to Home
              </Button>
              <Button
                onClick={() => setLocation('/services')}
                className="bg-gradient-to-r from-primary to-secondary text-white flex-1"
              >
                Explore Services <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default SuccessPage;