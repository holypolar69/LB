import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

const pricingPlans = [
  {
    name: "Starter Growth",
    price: "$499",
    period: "One-time",
    description: "Perfect for new businesses looking to establish a strong online presence.",
    features: [
      "Custom Website Design (5 pages)",
      "Basic SEO Optimization",
      "Social Media Integration",
      "Basic Analytics Setup",
      "Mobile Responsive Design",
      "Contact Form Setup",
      "1 Month Support"
    ],
    popular: false,
    buttonText: "Get Started",
    buttonLink: "/apply"
  },
  {
    name: "Scale Up",
    price: "$999",
    period: "One-time",
    description: "For businesses ready to accelerate growth with advanced marketing and automation.",
    features: [
      "Custom Website Design (10 pages)",
      "Comprehensive SEO Strategy",
      "Facebook/Instagram Ad Campaign",
      "Email Marketing Automation",
      "Google Analytics + Meta Pixel Setup",
      "Lead Capture System",
      "3 Months Support & Optimization",
      "Weekly Performance Reports"
    ],
    popular: true,
    buttonText: "Apply Now",
    buttonLink: "/apply"
  },
  {
    name: "Full System",
    price: "$1,499",
    period: "One-time",
    description: "Complete digital growth system with advanced AI tools and multi-channel marketing.",
    features: [
      "Premium Website with Custom Features",
      "AI-Powered Growth Strategy",
      "Multi-Platform Ad Campaigns",
      "Complete Analytics Dashboard",
      "Automated Lead Nurturing",
      "A/B Testing Framework",
      "CRM Integration & Setup",
      "6 Months Support & Optimization",
      "Priority Support Response"
    ],
    popular: false,
    buttonText: "Contact Us",
    buttonLink: "/contact"
  }
];

const additionalServices = [
  {
    name: "Logo & Brand Identity",
    price: "$199"
  },
  {
    name: "Content Creation Package",
    price: "$99/month"
  },
  {
    name: "Additional Ad Platform",
    price: "$99/month"
  },
  {
    name: "AI Chatbot Integration",
    price: "$399"
  },
  {
    name: "Website Maintenance",
    price: "$99/month"
  },
  {
    name: "Conversion Rate Optimization",
    price: "$399"
  }
];

const PricingPage = () => {
  return (
    <>
      <Helmet>
        <title>Pricing | LogicBoosts</title>
        <meta name="description" content="Explore our flexible pricing plans designed to help businesses of all sizes scale effectively." />
      </Helmet>
      <main>
        <section className="gradient-bg text-white py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-6"
            >
              Transparent Pricing
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl max-w-3xl mx-auto"
            >
              Choose Your Growth Plan
            </motion.p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {pricingPlans.map((plan, index) => (
                <motion.div 
                  key={plan.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className={`bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200 relative ${
                    plan.popular ? 'md:scale-105 z-10' : ''
                  }`}
                >
                  {plan.popular && (
                    <div className="bg-primary text-white text-center py-1 px-4 absolute top-0 right-0 left-0">
                      Most Popular
                    </div>
                  )}
                  <div className="p-6 pt-8">
                    <h2 className="text-2xl font-bold mb-2">{plan.name}</h2>
                    <div className="flex items-end mb-4">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-gray-500 ml-2">{plan.period}</span>
                    </div>
                    <p className="text-gray-600 mb-6">{plan.description}</p>
                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <Check className="text-primary mt-1 mr-2 h-4 w-4" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Link href={plan.buttonLink} className="block">
                      <Button 
                        className={`w-full py-3 ${plan.popular ? 'bg-primary hover:bg-secondary' : ''}`}
                        variant={plan.popular ? 'default' : 'outline'}
                      >
                        {plan.buttonText}
                      </Button>
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-3xl md:text-4xl font-bold mb-8 text-center"
            >
              Need a custom solution?
            </motion.h2>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-center mb-12"
            >
              <Link href="/contact" className="btn-primary">
                Contact us for a tailored growth plan.
              </Link>
            </motion.div>
            
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-3xl md:text-4xl font-bold mb-6 text-center"
            >
              Additional Services
            </motion.h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto mt-8">
              {additionalServices.map((service, index) => (
                <motion.div
                  key={service.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className="bg-white rounded-lg shadow-md p-6 border border-gray-200 flex justify-between items-center"
                >
                  <div className="font-medium">{service.name}</div>
                  <div className="text-primary font-bold">{service.price}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
            
        <section className="py-16 bg-[hsl(var(--gray-light))]">
          <div className="container mx-auto px-4 md:px-8">
            <div className="max-w-4xl mx-auto">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true, margin: "-100px" }}
                className="text-3xl md:text-4xl font-bold mb-8 text-center"
              >
                Frequently Asked Questions
              </motion.h2>
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true, margin: "-100px" }}
                className="space-y-6"
              >
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-2">Are the prices one-time or recurring?</h3>
                  <p className="text-gray-600">
                    All our core packages are one-time payments. Additional services like content creation or website maintenance are available on a monthly subscription basis if needed.
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-2">Can I customize the services in my plan?</h3>
                  <p className="text-gray-600">
                    Yes, we can customize any plan to better fit your specific needs. Contact us to discuss your requirements and we'll create a tailored solution.
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-2">What happens after my support period ends?</h3>
                  <p className="text-gray-600">
                    After your included support period ends, you can continue with our Website Maintenance plan at $99/month or choose from our other additional services as needed.
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-semibold mb-2">How quickly will I see results?</h3>
                  <p className="text-gray-600">
                    Results vary based on your industry, current position, and chosen strategy. Typically, clients begin seeing measurable improvements within 30-60 days, with more significant results after 90 days.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-3xl md:text-4xl font-bold mb-6"
            >
              Not Sure Which Plan Is Right for You?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-lg max-w-3xl mx-auto mb-8"
            >
              Schedule a free consultation to discuss your business needs and goals. We'll help you choose the perfect plan or create a custom solution.
            </motion.p>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true, margin: "-100px" }}
            >
              <Link href="/contact" className="btn-primary">
                Schedule a Free Consultation
              </Link>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
};

export default PricingPage;
