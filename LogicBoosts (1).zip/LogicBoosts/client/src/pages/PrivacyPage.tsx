import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const PrivacyPage = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | LogicBoosts</title>
        <meta name="description" content="Privacy Policy for LogicBoosts. Learn how we collect, use, and protect your personal information." />
      </Helmet>
      <main>
        <section className="gradient-bg text-white py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-6"
            >
              Privacy Policy
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl max-w-3xl mx-auto"
            >
              Last Updated: May 5, 2025
            </motion.p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8 max-w-4xl">
            <div className="prose prose-lg max-w-none">
              <h2>1. Introduction</h2>
              <p>
                LogicBoosts ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
              </p>
              <p>
                Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please do not access the site or use our services.
              </p>

              <h2>2. Information We Collect</h2>
              <h3>Personal Information</h3>
              <p>
                We may collect personal information that you voluntarily provide to us when you:
              </p>
              <ul>
                <li>Complete forms or fields on our website</li>
                <li>Submit a service application</li>
                <li>Contact us via email, social media, or other means</li>
                <li>Sign up for newsletters or other communications</li>
                <li>Create an account or client portal</li>
              </ul>
              <p>
                This information may include:
              </p>
              <ul>
                <li>Name, email address, phone number, and mailing address</li>
                <li>Company information, including size, industry, and website</li>
                <li>Project details and requirements</li>
                <li>Payment information (processed securely through third-party payment processors)</li>
              </ul>

              <h3>Automatically Collected Information</h3>
              <p>
                When you visit our website, we may automatically collect certain information about your device and usage patterns, including:
              </p>
              <ul>
                <li>IP address, browser type, and operating system</li>
                <li>Pages viewed, time spent on pages, links clicked</li>
                <li>Referring website or source</li>
                <li>Geographic location</li>
              </ul>

              <h2>3. How We Use Your Information</h2>
              <p>
                We may use the information we collect for various purposes, including to:
              </p>
              <ul>
                <li>Provide, operate, and maintain our services</li>
                <li>Process and fulfill service requests</li>
                <li>Communicate with you about our services, updates, or changes</li>
                <li>Send marketing and promotional communications (with your consent)</li>
                <li>Respond to your comments, questions, and requests</li>
                <li>Analyze usage patterns and improve our website and services</li>
                <li>Protect against fraud and unauthorized transactions</li>
                <li>Comply with legal obligations</li>
              </ul>

              <h2>4. Disclosure of Your Information</h2>
              <p>
                We may share your information in the following situations:
              </p>
              <ul>
                <li><strong>Service Providers:</strong> We may share your information with third-party vendors, service providers, and contractors who perform services for us.</li>
                <li><strong>Business Transfers:</strong> If we are involved in a merger, acquisition, or sale of all or a portion of our assets, your information may be transferred as part of that transaction.</li>
                <li><strong>Legal Requirements:</strong> We may disclose your information if required to do so by law or in response to valid legal requests.</li>
              </ul>
              <p>
                We do not sell, rent, or trade your personal information to third parties for marketing purposes.
              </p>

              <h2>5. Data Security</h2>
              <p>
                We implement reasonable security measures to protect your personal information from unauthorized access, misuse, or disclosure. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
              </p>

              <h2>6. Third-Party Websites</h2>
              <p>
                Our website may contain links to third-party websites or services. We are not responsible for the content or privacy practices of these websites. We encourage you to review the privacy policies of any third-party websites you visit.
              </p>

              <h2>7. Your Privacy Rights</h2>
              <p>
                Depending on your location, you may have certain rights regarding your personal information, including:
              </p>
              <ul>
                <li>The right to access personal information we hold about you</li>
                <li>The right to request correction of inaccurate information</li>
                <li>The right to request deletion of your information</li>
                <li>The right to restrict or object to processing of your information</li>
                <li>The right to data portability</li>
              </ul>
              <p>
                To exercise these rights, please contact us using the information provided in the "Contact Us" section below.
              </p>

              <h2>8. Children's Privacy</h2>
              <p>
                Our services are not intended for individuals under the age of 18. We do not knowingly collect personal information from children. If you are a parent or guardian and believe your child has provided us with personal information, please contact us immediately.
              </p>

              <h2>9. Updates to This Privacy Policy</h2>
              <p>
                We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes.
              </p>

              <h2>10. Contact Us</h2>
              <p>
                If you have questions or concerns about this Privacy Policy or our privacy practices, please contact us via Instagram @logicboosts.
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default PrivacyPage;