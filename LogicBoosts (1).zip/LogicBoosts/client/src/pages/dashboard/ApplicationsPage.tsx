import React from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Clock, CheckCircle, XCircle } from 'lucide-react';

const ApplicationsPage = () => {
  const [, setLocation] = useLocation();

  // Mock applications data
  const applications = [
    {
      id: 1,
      serviceName: "Brand Strategy & Digital Marketing",
      date: "May 3, 2025",
      status: "approved",
      description: "Complete brand refresh and digital marketing campaign for Q3 2025.",
    },
    {
      id: 2,
      serviceName: "Web Development",
      date: "April 28, 2025",
      status: "pending",
      description: "E-commerce website redesign with updated UX/UI and payment processing.",
    },
    {
      id: 3,
      serviceName: "Data Analytics & CRM Implementation",
      date: "April 15, 2025",
      status: "rejected",
      description: "Data analysis and CRM setup for sales team with performance tracking.",
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-amber-500" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Approved</Badge>;
      case 'pending':
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">Pending</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>;
      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="container py-12"
    >
      <div className="flex items-center mb-8">
        <Button
          variant="ghost"
          size="sm"
          className="mr-4"
          onClick={() => setLocation('/dashboard')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Applications</h1>
          <p className="text-muted-foreground">
            View and manage your service applications
          </p>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full mb-8">
        <TabsList className="w-full bg-muted sm:w-auto">
          <TabsTrigger value="all" className="flex-1 sm:flex-initial">
            All
          </TabsTrigger>
          <TabsTrigger value="approved" className="flex-1 sm:flex-initial">
            <CheckCircle className="h-4 w-4 mr-2" />
            Approved
          </TabsTrigger>
          <TabsTrigger value="pending" className="flex-1 sm:flex-initial">
            <Clock className="h-4 w-4 mr-2" />
            Pending
          </TabsTrigger>
          <TabsTrigger value="rejected" className="flex-1 sm:flex-initial">
            <XCircle className="h-4 w-4 mr-2" />
            Rejected
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <div className="space-y-4">
            {applications.map((app) => (
              <ApplicationCard key={app.id} application={app} />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="approved">
          <div className="space-y-4">
            {applications
              .filter(app => app.status === 'approved')
              .map((app) => (
                <ApplicationCard key={app.id} application={app} />
              ))}
          </div>
        </TabsContent>
        
        <TabsContent value="pending">
          <div className="space-y-4">
            {applications
              .filter(app => app.status === 'pending')
              .map((app) => (
                <ApplicationCard key={app.id} application={app} />
              ))}
          </div>
        </TabsContent>
        
        <TabsContent value="rejected">
          <div className="space-y-4">
            {applications
              .filter(app => app.status === 'rejected')
              .map((app) => (
                <ApplicationCard key={app.id} application={app} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      <div className="text-center">
        <Button
          onClick={() => setLocation('/apply')}
          className="bg-gradient-to-r from-primary to-secondary text-white"
        >
          Submit New Application
        </Button>
      </div>
    </motion.div>
  );
};

interface ApplicationProps {
  application: {
    id: number;
    serviceName: string;
    date: string;
    status: string;
    description: string;
  };
}

const ApplicationCard = ({ application }: ApplicationProps) => {
  const [, setLocation] = useLocation();

  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="pb-2 flex flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle className="text-xl font-bold">{application.serviceName}</CardTitle>
          <CardDescription>Applied on {application.date}</CardDescription>
        </div>
        <div>
          {getStatusBadge(application.status)}
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-4">{application.description}</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {getStatusIcon(application.status)}
            <span className="ml-2 text-sm capitalize">{application.status}</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation(`/dashboard/applications/${application.id}`)}
          >
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ApplicationsPage;