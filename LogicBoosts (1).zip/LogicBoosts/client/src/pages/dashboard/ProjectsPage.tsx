import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter
} from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Calendar, 
  BarChart, 
  Users, 
  FileText, 
  MessageSquare, 
  Clock, 
  CheckCircle,
  ArrowRight,
  Download
} from 'lucide-react';

const ProjectsPage = () => {
  const [, setLocation] = useLocation();

  // Mock project data
  const projects = [
    {
      id: 1,
      name: "Website Redesign",
      startDate: "March 15, 2025",
      endDate: "July 30, 2025",
      progress: 65,
      status: "In Progress",
      description: "Complete redesign of company website with modern UI/UX, improved mobile responsiveness, and e-commerce capabilities.",
      team: ["John Smith", "Emma Johnson", "Michael Chen"],
      tasks: [
        { name: "Wireframing", status: "completed", date: "April 2, 2025" },
        { name: "UI Design", status: "completed", date: "April 20, 2025" },
        { name: "Frontend Development", status: "in-progress", date: "May 15, 2025" },
        { name: "Backend Integration", status: "scheduled", date: "June 1, 2025" },
        { name: "Testing & QA", status: "scheduled", date: "June 15, 2025" },
        { name: "Launch", status: "scheduled", date: "July 30, 2025" }
      ]
    },
    {
      id: 2,
      name: "Marketing Campaign",
      startDate: "April 1, 2025",
      endDate: "August 31, 2025",
      progress: 30,
      status: "In Progress",
      description: "Comprehensive digital marketing campaign including SEO, content strategy, social media, and PPC advertising.",
      team: ["Sarah Patel", "David Wilson", "Jessica Lee"],
      tasks: [
        { name: "Market Research", status: "completed", date: "April 15, 2025" },
        { name: "Strategy Development", status: "completed", date: "April 30, 2025" },
        { name: "Content Creation", status: "in-progress", date: "May 31, 2025" },
        { name: "Campaign Launch", status: "scheduled", date: "June 15, 2025" },
        { name: "Performance Monitoring", status: "scheduled", date: "July 1, 2025" },
        { name: "Campaign Analysis", status: "scheduled", date: "August 31, 2025" }
      ]
    },
    {
      id: 3,
      name: "Brand Strategy",
      startDate: "April 20, 2025",
      endDate: "June 30, 2025",
      progress: 10,
      status: "Planning Phase",
      description: "Development of comprehensive brand strategy including brand identity, positioning, messaging, and visual guidelines.",
      team: ["Robert Thompson", "Anna Garcia", "James Wilson"],
      tasks: [
        { name: "Brand Audit", status: "in-progress", date: "May 5, 2025" },
        { name: "Market Research", status: "scheduled", date: "May 15, 2025" },
        { name: "Brand Positioning", status: "scheduled", date: "May 30, 2025" },
        { name: "Visual Identity", status: "scheduled", date: "June 15, 2025" },
        { name: "Brand Guidelines", status: "scheduled", date: "June 30, 2025" }
      ]
    }
  ];

  const [selectedProject, setSelectedProject] = useState(projects[0]);
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');

  const getTaskIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'in-progress':
        return <Clock className="h-4 w-4 text-amber-500" />;
      case 'scheduled':
        return <Calendar className="h-4 w-4 text-gray-500" />;
      default:
        return null;
    }
  };

  const handleViewProject = (project: typeof projects[0]) => {
    setSelectedProject(project);
    setViewMode('detail');
  };

  const progressColorClass = (progress: number) => {
    if (progress < 25) return "bg-red-500";
    if (progress < 50) return "bg-amber-500";
    if (progress < 75) return "bg-blue-500";
    return "bg-green-500";
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="container py-12"
    >
      <div className="flex items-center mb-8">
        <Button
          variant="ghost"
          size="sm"
          className="mr-4"
          onClick={() => {
            if (viewMode === 'detail') {
              setViewMode('list');
            } else {
              setLocation('/dashboard');
            }
          }}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          {viewMode === 'detail' ? 'Back to Projects' : 'Back to Dashboard'}
        </Button>
        <div>
          <h1 className="text-3xl font-bold">
            {viewMode === 'detail' ? selectedProject.name : 'Projects'}
          </h1>
          <p className="text-muted-foreground">
            {viewMode === 'detail' 
              ? `${selectedProject.status} · ${selectedProject.progress}% Complete` 
              : 'View and manage your ongoing projects'}
          </p>
        </div>
      </div>

      {viewMode === 'list' ? (
        <div className="space-y-6">
          {projects.map((project) => (
            <Card key={project.id} className="shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl font-bold">{project.name}</CardTitle>
                  <div className="text-sm font-medium px-2 py-1 rounded-full bg-primary/10 text-primary">
                    {project.status}
                  </div>
                </div>
                <CardDescription>
                  {project.startDate} - {project.endDate}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progress</span>
                    <span>{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className={`h-2 ${progressColorClass(project.progress)}`} />
                </div>
                <p className="text-muted-foreground mb-4">{project.description}</p>
                <div className="flex flex-col sm:flex-row gap-4 sm:gap-8">
                  <div>
                    <div className="text-sm font-medium mb-1 flex items-center">
                      <Calendar className="h-4 w-4 mr-1 text-primary" />
                      Timeline
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {project.startDate} - {project.endDate}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium mb-1 flex items-center">
                      <Users className="h-4 w-4 mr-1 text-primary" />
                      Team
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {project.team.length} members
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium mb-1 flex items-center">
                      <FileText className="h-4 w-4 mr-1 text-primary" />
                      Tasks
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {project.tasks.filter(t => t.status === 'completed').length} of {project.tasks.length} completed
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0 border-t">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => handleViewProject(project)}
                >
                  View Project Details
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          <Card className="shadow-sm">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">{selectedProject.startDate} - {selectedProject.endDate}</div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm px-2 py-1 rounded-full bg-primary/10 text-primary">
                      {selectedProject.status}
                    </div>
                    <div className="text-sm px-2 py-1 rounded-full bg-muted text-muted-foreground">
                      {selectedProject.progress}% Complete
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Contact Team
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Project Description</h3>
                <p className="text-muted-foreground">{selectedProject.description}</p>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Progress</h3>
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Overall Completion</span>
                    <span>{selectedProject.progress}%</span>
                  </div>
                  <Progress value={selectedProject.progress} className={`h-3 ${progressColorClass(selectedProject.progress)}`} />
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Project Team</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedProject.team.map((member, index) => (
                    <div key={index} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                      {member}
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Timeline & Tasks</h3>
                <div className="space-y-4">
                  {selectedProject.tasks.map((task, index) => (
                    <div key={index} className="flex items-start border-l-2 border-primary/30 pl-4 py-1">
                      {getTaskIcon(task.status)}
                      <div className="ml-2">
                        <div className="font-medium">{task.name}</div>
                        <div className="text-sm text-muted-foreground flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          {task.date}
                          <span className="mx-2">•</span>
                          <span className="capitalize">{task.status.replace('-', ' ')}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t flex justify-between">
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Download Report
              </Button>
              <Button 
                className="bg-gradient-to-r from-primary to-secondary text-white"
                size="sm"
              >
                <BarChart className="mr-2 h-4 w-4" />
                View Metrics
              </Button>
            </CardFooter>
          </Card>
          
          <div className="text-center">
            <Button
              variant="outline"
              onClick={() => setViewMode('list')}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to All Projects
            </Button>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default ProjectsPage;