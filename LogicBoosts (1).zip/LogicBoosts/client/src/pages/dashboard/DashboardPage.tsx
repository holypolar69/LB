import React from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { BarChart, Users, FileText, Settings, ChevronRight, Activity, ArrowUpRight, Calendar, LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

const DashboardPage = () => {
  const [, setLocation] = useLocation();
  const { logout } = useAuth();

  // Mock data for the dashboard
  const stats = [
    {
      title: "Active Projects",
      value: "3",
      change: "+1",
      icon: <FileText className="h-4 w-4 text-primary" />,
      link: "/dashboard/projects"
    },
    {
      title: "Meetings Scheduled",
      value: "2",
      change: "+1",
      icon: <Calendar className="h-4 w-4 text-primary" />,
      link: "/dashboard/projects"
    },
    {
      title: "Performance",
      value: "89%",
      change: "+6%",
      icon: <Activity className="h-4 w-4 text-primary" />,
      link: "/dashboard/projects"
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="container py-12 mx-auto px-4"
    >
      <div className="flex justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Welcome Back, Admin</h1>
          <p className="text-muted-foreground">
            Here's an overview of your projects and performance metrics.
          </p>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          className="flex items-center"
          onClick={() => {
            logout();
            setLocation('/admin/login');
          }}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>

      <div className="grid gap-6 mb-8 grid-cols-1 md:grid-cols-3">
        {stats.map((stat, index) => (
          <Card key={index} className="shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-sm font-medium">
                {stat.icon}
                <span className="ml-2">{stat.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline justify-between">
                <div className="text-3xl font-bold">{stat.value}</div>
                <div className="flex items-center text-sm text-green-600">
                  {stat.change}
                  <ArrowUpRight className="ml-1 h-4 w-4" />
                </div>
              </div>
              <Button
                variant="link"
                className="p-0 mt-2 h-auto text-primary text-sm"
                onClick={() => setLocation(stat.link)}
              >
                View details <ChevronRight className="ml-1 h-3 w-3" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="projects" className="w-full">
        <TabsList className="w-full bg-muted sm:w-auto">
          <TabsTrigger value="projects" className="flex-1 sm:flex-initial">
            <FileText className="h-4 w-4 mr-2" />
            Projects
          </TabsTrigger>
          <TabsTrigger value="applications" className="flex-1 sm:flex-initial">
            <Users className="h-4 w-4 mr-2" />
            Applications
          </TabsTrigger>
          <TabsTrigger value="metrics" className="flex-1 sm:flex-initial">
            <BarChart className="h-4 w-4 mr-2" />
            Metrics
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex-1 sm:flex-initial">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>
        <TabsContent value="projects" className="bg-white p-6 rounded-b-lg shadow-sm border">
          <h3 className="text-lg font-semibold mb-4">Active Projects</h3>
          <div className="space-y-4">
            {/* Mock projects */}
            <div className="border rounded-lg p-4 flex justify-between items-center hover:bg-muted/50 transition-colors">
              <div>
                <h4 className="font-medium">Website Redesign</h4>
                <p className="text-sm text-muted-foreground">In progress - 65% complete</p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setLocation('/dashboard/projects')}
              >
                View
              </Button>
            </div>
            <div className="border rounded-lg p-4 flex justify-between items-center hover:bg-muted/50 transition-colors">
              <div>
                <h4 className="font-medium">Marketing Campaign</h4>
                <p className="text-sm text-muted-foreground">In progress - 30% complete</p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setLocation('/dashboard/projects')}
              >
                View
              </Button>
            </div>
            <div className="border rounded-lg p-4 flex justify-between items-center hover:bg-muted/50 transition-colors">
              <div>
                <h4 className="font-medium">Brand Strategy</h4>
                <p className="text-sm text-muted-foreground">Planning phase - 10% complete</p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setLocation('/dashboard/projects')}
              >
                View
              </Button>
            </div>
          </div>
          <div className="mt-6 text-center">
            <Button 
              onClick={() => setLocation('/dashboard/projects')}
              className="bg-gradient-to-r from-primary to-secondary text-white"
            >
              View All Projects
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="applications" className="bg-white p-6 rounded-b-lg shadow-sm border">
          <div className="text-center py-12">
            <Button
              onClick={() => setLocation('/dashboard/applications')}
              className="bg-gradient-to-r from-primary to-secondary text-white"
            >
              View Applications
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="metrics" className="bg-white p-6 rounded-b-lg shadow-sm border">
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">Performance metrics will be available soon.</p>
            <Button
              variant="outline"
              onClick={() => setLocation('/dashboard/projects')}
            >
              View Projects
            </Button>
          </div>
        </TabsContent>
        
        <TabsContent value="settings" className="bg-white p-6 rounded-b-lg shadow-sm border">
          <div className="text-center py-12">
            <Button
              onClick={() => setLocation('/dashboard/settings')}
            >
              Manage Settings
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default DashboardPage;