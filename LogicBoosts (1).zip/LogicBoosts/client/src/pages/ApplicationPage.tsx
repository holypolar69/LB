import { Helmet } from 'react-helmet';
import ApplicationForm from '@/components/application/ApplicationForm';

const ApplicationPage = () => {
  return (
    <>
      <Helmet>
        <title>Service Application | LogicBoosts</title>
        <meta name="description" content="Apply for LogicBoosts services. We'll help you scale your business with cutting-edge technology and proven strategies." />
      </Helmet>
      <main>
        <section className="gradient-bg text-white py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Service Application
            </h1>
            <p className="text-lg md:text-xl max-w-3xl mx-auto">
              Take the first step towards accelerated growth. Complete the application below to help us understand your business needs.
            </p>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 md:px-8">
            <h2 className="text-3xl font-bold text-center mb-12">What to Expect After Applying</h2>
            <div className="max-w-3xl mx-auto space-y-8">
              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold">1</div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Application Review</h3>
                  <p className="text-gray-600">Our team will review your application within 1-2 business days to determine if we're a good fit for your project.</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold">2</div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Discovery Call</h3>
                  <p className="text-gray-600">We'll schedule a 30-minute call to discuss your business in detail, understand your goals, and answer any questions you may have.</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold">3</div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Custom Growth Plan</h3>
                  <p className="text-gray-600">Based on our conversation, we'll create a tailored growth plan with specific strategies, timelines, and pricing for your business.</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary font-bold">4</div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Kickoff & Implementation</h3>
                  <p className="text-gray-600">Once you approve the plan, we'll schedule a kickoff meeting to start the implementation process and begin growing your business.</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        <ApplicationForm />
      </main>
    </>
  );
};

export default ApplicationPage;
