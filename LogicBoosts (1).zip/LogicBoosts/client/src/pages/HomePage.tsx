import { Helmet } from 'react-helmet';
import HeroSection from '@/components/home/HeroSection';
import MissionSection from '@/components/home/MissionSection';
import ServicesSection from '@/components/home/ServicesSection';
import FeaturesSection from '@/components/home/FeaturesSection';
import CtaSection from '@/components/home/CtaSection';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>LogicBoosts - Smart Growth Starts Here</title>
        <meta name="description" content="LogicBoosts is a growth company using AI, web design, and digital strategy to scale modern brands." />
      </Helmet>
      <main>
        <HeroSection />
        <MissionSection />
        <ServicesSection />
        <FeaturesSection />
        <CtaSection />
      </main>
    </>
  );
};

export default HomePage;
