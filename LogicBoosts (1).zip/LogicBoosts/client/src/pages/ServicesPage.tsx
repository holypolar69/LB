import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { Check } from 'lucide-react';

const services = [
  {
    id: "ai-scaling",
    title: "AI-Powered Scaling",
    description: "Leverage artificial intelligence to automate processes, predict trends, and optimize growth strategies.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    features: [
      "AI-driven lead generation and qualification",
      "Automated customer journey optimization",
      "Predictive analytics for business decisions",
      "Smart content creation and distribution",
      "Conversion rate optimization with machine learning",
      "Automated A/B testing and optimization"
    ],
    detailedDescription: "Our AI-Powered Scaling service uses cutting-edge artificial intelligence to automate and optimize your growth processes. From lead generation to customer journey optimization, our AI tools can predict trends, automate workflows, and make data-driven decisions to help your business scale efficiently."
  },
  {
    id: "web-design",
    title: "High-Conversion Websites",
    description: "Design and develop modern, responsive websites that are optimized for user experience and conversions.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
      </svg>
    ),
    features: [
      "User-centered design approach",
      "Mobile-first responsive layouts",
      "Search engine optimization (SEO)",
      "Conversion-focused user interface",
      "Performance optimization for fast loading",
      "Accessibility compliance for all users"
    ],
    detailedDescription: "We design and develop websites that don't just look great—they convert visitors into customers. Our High-Conversion Websites service focuses on creating user-friendly, mobile-responsive sites that are optimized for both search engines and conversions. We apply best practices in UI/UX design to ensure your website effectively communicates your value proposition and guides users toward conversion."
  },
  {
    id: "digital-ads",
    title: "Strategic Digital Ads",
    description: "Create and manage targeted advertising campaigns that drive real results and maximize ROI.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
      </svg>
    ),
    features: [
      "Multi-platform ad campaign management",
      "Audience targeting and segmentation",
      "A/B testing for ad creative and copy",
      "Performance tracking and analytics",
      "Budget optimization across platforms",
      "Retargeting and remarketing strategies"
    ],
    detailedDescription: "Our Strategic Digital Ads service helps you reach the right audience with the right message at the right time. We create and manage targeted advertising campaigns across multiple platforms, optimizing your ad spend to maximize ROI. Our data-driven approach ensures that your marketing budget is allocated effectively, driving more qualified leads and conversions."
  },
  {
    id: "analytics",
    title: "Analytics & Testing",
    description: "Implement comprehensive analytics and testing frameworks to drive data-informed decisions.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    ),
    features: [
      "Custom analytics dashboard setup",
      "User behavior tracking and analysis",
      "Conversion funnel analysis",
      "Systematic A/B and multivariate testing",
      "Heat mapping and session recording",
      "Data-driven recommendations for optimization"
    ],
    detailedDescription: "Our Analytics & Testing service provides you with the insights you need to make informed business decisions. We implement comprehensive analytics frameworks to track user behavior and conversion metrics, conduct systematic A/B tests to optimize performance, and provide data-driven recommendations to improve your digital properties and marketing campaigns."
  },
  {
    id: "growth-strategy",
    title: "Growth Strategy Consulting",
    description: "Develop comprehensive growth strategies tailored to your business goals and market position.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
      </svg>
    ),
    features: [
      "Comprehensive business analysis",
      "Market and competitor research",
      "Customer journey mapping",
      "Growth opportunity identification",
      "Actionable strategy development",
      "Implementation roadmap creation"
    ],
    detailedDescription: "Our Growth Strategy Consulting service helps you develop a comprehensive plan for sustainable business growth. We analyze your business, market, and competition to identify growth opportunities and develop actionable strategies. Our consultants work closely with your team to create an implementation roadmap and provide ongoing guidance to ensure your growth initiatives succeed."
  }
];

const ServicesPage = () => {
  return (
    <>
      <Helmet>
        <title>Our Services | LogicBoosts</title>
        <meta name="description" content="Explore our range of services including AI-Powered Scaling, High-Conversion Websites, and Strategic Digital Ads." />
      </Helmet>
      <main>
        <section className="gradient-bg text-white py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-6"
            >
              Our Services
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl max-w-3xl mx-auto"
            >
              We offer a comprehensive suite of services designed to help your business grow and thrive in the digital landscape.
            </motion.p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8">
            {services.map((service, index) => (
              <motion.div 
                key={service.id}
                id={service.id}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true, margin: "-100px" }}
                className={`py-12 ${index % 2 === 0 ? '' : 'bg-gray-50'}`}
              >
                <div className="max-w-5xl mx-auto">
                  <div className="flex flex-col md:flex-row gap-8 items-start">
                    <div className="md:w-1/2">
                      <div className="bg-primary p-3 rounded-lg inline-block text-white mb-4">
                        {service.icon}
                      </div>
                      <h2 className="text-3xl font-bold mb-4">{service.title}</h2>
                      <p className="text-lg mb-6">{service.detailedDescription}</p>
                      <Link href="/apply" className="btn-primary">
                        Get Started
                      </Link>
                    </div>
                    <div className="md:w-1/2 bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-semibold mb-4">What's Included</h3>
                      <ul className="space-y-3">
                        {service.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start">
                            <div className="checkbox-circle mr-3 mt-0.5">
                              <Check size={16} />
                            </div>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-3xl md:text-4xl font-bold mb-6"
            >
              Ready to Grow Your Business?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-lg max-w-3xl mx-auto mb-8"
            >
              Contact us today to discuss how our services can help you achieve your business goals.
            </motion.p>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true, margin: "-100px" }}
              className="flex flex-col sm:flex-row justify-center gap-4"
            >
              <Link href="/apply" className="btn-primary">
                Apply Now
              </Link>
              <Link href="/contact" className="btn-secondary">
                Contact Us
              </Link>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
};

export default ServicesPage;
