import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'wouter';

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Us | LogicBoosts</title>
        <meta name="description" content="Learn about LogicBoosts, our mission, our team, and our approach to helping businesses grow." />
      </Helmet>
      <main>
        <section className="gradient-bg text-white py-16 md:py-24">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold mb-6"
            >
              About LogicBoosts
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl max-w-3xl mx-auto"
            >
              We're a growth-focused agency that helps businesses scale through AI-powered strategies, beautiful web design, and data-driven marketing.
            </motion.p>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8">
            <div className="max-w-5xl mx-auto">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true, margin: "-100px" }}
                className="text-3xl md:text-4xl font-bold mb-8 text-center"
              >
                Our Story
              </motion.h2>
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true, margin: "-100px" }}
                className="space-y-6 text-lg"
              >
                <p>
                  LogicBoosts was founded by a group of passionate teens who saw a gap in the market for modern, technology-driven growth solutions. We noticed that many businesses were struggling to adapt to the rapidly changing digital landscape, while others were paying premium prices for outdated strategies that didn't deliver results.
                </p>
                <p>
                  We started LogicBoosts with a simple mission: to empower businesses with the tools, strategies, and systems they need to scale rapidly and intelligently in a digital world. We believe that cutting-edge technology, combined with creative strategies and data-driven decisions, is the key to sustainable growth.
                </p>
                <p>
                  What sets us apart is our unique approach that combines AI-powered solutions with human creativity and strategic thinking. We're not just another agency—we're a growth partner that's invested in your success.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-[hsl(var(--gray-light))]">
          <div className="container mx-auto px-4 md:px-8">
            <div className="max-w-5xl mx-auto">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true, margin: "-100px" }}
                className="text-3xl md:text-4xl font-bold mb-8 text-center"
              >
                Our Approach
              </motion.h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className="bg-white p-6 rounded-lg shadow-md"
                >
                  <div className="bg-primary p-3 rounded-lg inline-block text-white mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-3">Data-Driven</h3>
                  <p>
                    We make decisions based on data, not hunches. Every strategy we implement is backed by analytics and constantly optimized for performance.
                  </p>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className="bg-white p-6 rounded-lg shadow-md"
                >
                  <div className="bg-primary p-3 rounded-lg inline-block text-white mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-3">Results-Focused</h3>
                  <p>
                    We're not interested in vanity metrics. Our success is measured by your growth—whether that's increased revenue, more qualified leads, or higher conversion rates.
                  </p>
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className="bg-white p-6 rounded-lg shadow-md"
                >
                  <div className="bg-primary p-3 rounded-lg inline-block text-white mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-3">Collaborative</h3>
                  <p>
                    We work closely with your team, integrating our expertise with your industry knowledge to create strategies that are tailored to your specific needs.
                  </p>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4 md:px-8 text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-3xl md:text-4xl font-bold mb-6"
            >
              Ready to Grow With Us?
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true, margin: "-100px" }}
              className="text-lg max-w-3xl mx-auto mb-8"
            >
              Let's start a conversation about how we can help your business scale to new heights.
            </motion.p>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true, margin: "-100px" }}
              className="flex flex-col sm:flex-row justify-center gap-4"
            >
              <Link href="/apply" className="btn-primary">
                Apply Now
              </Link>
              <Link href="/contact" className="btn-secondary">
                Contact Us
              </Link>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
};

export default AboutPage;
