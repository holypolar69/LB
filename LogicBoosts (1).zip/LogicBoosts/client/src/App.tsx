import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AnimatePresence, motion } from "framer-motion";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import ServicesPage from "@/pages/ServicesPage";
import AboutPage from "@/pages/AboutPage";
import PricingPage from "@/pages/PricingPage";
import ContactPage from "@/pages/ContactPage";
import ApplicationPage from "@/pages/ApplicationPage";
import TermsPage from "@/pages/TermsPage";
import PrivacyPage from "@/pages/PrivacyPage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import React, { useEffect } from "react";
import { ApplicationProvider } from "@/context/ApplicationContext";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

function ScrollToTop() {
  const [location] = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  
  return null;
}

const pageVariants = {
  initial: {
    opacity: 0,
    y: 20
  },
  in: {
    opacity: 1,
    y: 0
  },
  out: {
    opacity: 0,
    y: -20
  }
};

const pageTransition = {
  type: "tween",
  ease: "anticipate",
  duration: 0.3
};

function Router() {
  const [location] = useLocation();
  const isDashboardPage = location.startsWith('/dashboard');
  
  // Lazy load components to avoid import errors until they're created
  const ApplicationPersonalPage = React.lazy(() => import('@/pages/application/PersonalPage'));
  const ApplicationBusinessPage = React.lazy(() => import('@/pages/application/BusinessPage'));
  const ApplicationServicesPage = React.lazy(() => import('@/pages/application/ServicesPage'));
  const ApplicationProjectPage = React.lazy(() => import('@/pages/application/ProjectPage'));
  const ApplicationSubmitPage = React.lazy(() => import('@/pages/application/SubmitPage'));
  const ApplicationSuccessPage = React.lazy(() => import('@/pages/application/SuccessPage'));
  
  const ClientDashboardPage = React.lazy(() => import('@/pages/dashboard/DashboardPage'));
  const ClientApplicationsPage = React.lazy(() => import('@/pages/dashboard/ApplicationsPage'));
  const ClientProjectsPage = React.lazy(() => import('@/pages/dashboard/ProjectsPage'));
  const ClientSettingsPage = React.lazy(() => import('@/pages/dashboard/SettingsPage'));
  
  return (
    <div className="flex flex-col min-h-screen">
      {!isDashboardPage && <Navbar />}
      <ScrollToTop />
      <div className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={location}
            initial="initial"
            animate="in"
            exit="out"
            variants={pageVariants}
            transition={pageTransition}
          >
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/services" component={ServicesPage} />
              <Route path="/about" component={AboutPage} />
              <Route path="/pricing" component={PricingPage} />
              <Route path="/contact" component={ContactPage} />
              <Route path="/terms" component={TermsPage} />
              <Route path="/privacy" component={PrivacyPage} />
              
              {/* Application Process Routes */}
              <Route path="/apply" component={ApplicationPage} />
              <ApplicationProvider>
                <React.Suspense fallback={<div className="flex items-center justify-center h-screen">Loading...</div>}>
                  <Route path="/apply/personal" component={ApplicationPersonalPage} />
                  <Route path="/apply/business" component={ApplicationBusinessPage} />
                  <Route path="/apply/services" component={ApplicationServicesPage} />
                  <Route path="/apply/project" component={ApplicationProjectPage} />
                  <Route path="/apply/submit" component={ApplicationSubmitPage} />
                  <Route path="/apply/success" component={ApplicationSuccessPage} />
                </React.Suspense>
              </ApplicationProvider>
              
              {/* Admin Login Route */}
              <React.Suspense fallback={<div className="flex items-center justify-center h-screen">Loading...</div>}>
                <Route path="/admin/login" component={React.lazy(() => import('@/pages/admin/LoginPage'))} />
              </React.Suspense>
              
              {/* Admin Dashboard Routes - Protected */}
              <React.Suspense fallback={<div className="flex items-center justify-center h-screen">Loading...</div>}>
                <ProtectedRoute 
                  path="/dashboard" 
                  component={ClientDashboardPage} 
                />
                <ProtectedRoute 
                  path="/dashboard/applications" 
                  component={ClientApplicationsPage} 
                />
                <ProtectedRoute 
                  path="/dashboard/projects" 
                  component={ClientProjectsPage} 
                />
                <ProtectedRoute 
                  path="/dashboard/settings" 
                  component={ClientSettingsPage} 
                />
              </React.Suspense>
              
              <Route component={NotFound} />
            </Switch>
          </motion.div>
        </AnimatePresence>
      </div>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
