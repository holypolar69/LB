import React, { createContext, useState, useContext, ReactNode } from 'react';
import { z } from 'zod';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export interface FormValues {
  // Personal information
  fullName: string;
  email: string;
  phone: string;

  // Business information
  companyName: string;
  website: string;
  industry: string;
  companySize: string;

  // Services information
  services: string[];
  budget: string;
  timeline: string;

  // Project information
  projectDescription: string;
  goals: string;
  challenges: string;
}

export const initialFormValues: FormValues = {
  fullName: "",
  email: "",
  phone: "",
  companyName: "",
  website: "",
  industry: "",
  companySize: "",
  services: [],
  budget: "",
  timeline: "",
  projectDescription: "",
  goals: "",
  challenges: "",
};

interface ApplicationContextType {
  formValues: FormValues;
  updateFormValues: (values: Partial<FormValues>) => void;
  resetForm: () => void;
  submitApplication: () => void;
  isPending: boolean;
}

const ApplicationContext = createContext<ApplicationContextType | undefined>(undefined);

export const ApplicationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [, setLocation] = useLocation();
  const [formValues, setFormValues] = useState<FormValues>(initialFormValues);
  const { toast } = useToast();

  const applicationMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/applications", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "We'll review your application and get back to you soon!",
        variant: "default",
      });
      setFormValues(initialFormValues);
      setLocation('/apply/success');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateFormValues = (values: Partial<FormValues>) => {
    setFormValues((prev) => ({ ...prev, ...values }));
  };

  const resetForm = () => {
    setFormValues(initialFormValues);
  };

  const submitApplication = () => {
    applicationMutation.mutate(formValues);
  };

  return (
    <ApplicationContext.Provider
      value={{
        formValues,
        updateFormValues,
        resetForm,
        submitApplication,
        isPending: applicationMutation.isPending,
      }}
    >
      {children}
    </ApplicationContext.Provider>
  );
};

export const useApplication = (): ApplicationContextType => {
  const context = useContext(ApplicationContext);
  if (context === undefined) {
    throw new Error('useApplication must be used within an ApplicationProvider');
  }
  return context;
};