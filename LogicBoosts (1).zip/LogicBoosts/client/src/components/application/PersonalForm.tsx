import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { validateEmail, validateName, validatePhone } from "@/lib/utils";
import { FormValues } from "./ApplicationForm";

interface PersonalFormProps {
  values: FormValues;
  onChange: (values: Partial<FormValues>) => void;
  onNext: () => void;
}

const PersonalForm = ({ values, onChange, onNext }: PersonalFormProps) => {
  const [errors, setErrors] = useState({
    fullName: "",
    email: "",
    phone: "",
  });

  const [isFormValid, setIsFormValid] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onChange({ [name]: value });
  };

  const validateForm = () => {
    const newErrors = {
      fullName: !validateName(values.fullName) ? "Please enter a valid name" : "",
      email: !validateEmail(values.email) ? "Please enter a valid email address" : "",
      phone: !validatePhone(values.phone) ? "Please enter a valid phone number" : "",
    };

    setErrors(newErrors);
    return !newErrors.fullName && !newErrors.email && !newErrors.phone;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onNext();
    }
  };

  useEffect(() => {
    // Re-validate whenever values change
    const isValid = 
      validateName(values.fullName) && 
      validateEmail(values.email) && 
      validatePhone(values.phone);
    
    setIsFormValid(isValid);
  }, [values]);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h3 className="text-xl font-semibold mb-4">Personal Information</h3>

      <div className="space-y-2">
        <Label htmlFor="fullName">
          Full Name<span className="text-red-500">*</span>
        </Label>
        <Input
          id="fullName"
          name="fullName"
          value={values.fullName}
          onChange={handleChange}
          placeholder="Your name"
          className="w-full"
          required
        />
        {errors.fullName && <p className="text-sm text-red-500">{errors.fullName}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">
          Email Address<span className="text-red-500">*</span>
        </Label>
        <Input
          id="email"
          name="email"
          type="email"
          value={values.email}
          onChange={handleChange}
          placeholder="Your email"
          className="w-full"
          required
        />
        {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone">Phone Number (Optional)</Label>
        <Input
          id="phone"
          name="phone"
          type="tel"
          value={values.phone}
          onChange={handleChange}
          placeholder="Your phone number"
          className="w-full"
        />
        {errors.phone && <p className="text-sm text-red-500">{errors.phone}</p>}
      </div>

      <div className="pt-4 text-right">
        <Button type="submit" className="btn-primary">
          Next
        </Button>
      </div>
    </form>
  );
};

export default PersonalForm;
