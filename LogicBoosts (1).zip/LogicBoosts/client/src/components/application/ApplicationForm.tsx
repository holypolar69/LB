import { useState } from "react";
import { motion } from "framer-motion";
import PersonalForm from "./PersonalForm";
import BusinessForm from "./BusinessForm";
import ServicesForm from "./ServicesForm";
import ProjectForm from "./ProjectForm";
import SubmitForm from "./SubmitForm";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export interface FormValues {
  // Personal information
  fullName: string;
  email: string;
  phone: string;

  // Business information
  companyName: string;
  website: string;
  industry: string;
  companySize: string;

  // Services information
  services: string[];
  budget: string;
  timeline: string;

  // Project information
  projectDescription: string;
  goals: string;
  challenges: string;
}

const initialFormValues: FormValues = {
  fullName: "",
  email: "",
  phone: "",
  companyName: "",
  website: "",
  industry: "",
  companySize: "",
  services: [],
  budget: "",
  timeline: "",
  projectDescription: "",
  goals: "",
  challenges: "",
};

const ApplicationForm = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formValues, setFormValues] = useState<FormValues>(initialFormValues);
  const { toast } = useToast();

  const submitApplication = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/applications", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "We'll get back to you soon!",
        variant: "default",
      });
      setFormValues(initialFormValues);
      setCurrentStep(1);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const nextStep = () => {
    setCurrentStep((prev) => Math.min(prev + 1, 5));
  };

  const prevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  const handleSubmit = () => {
    submitApplication.mutate(formValues);
  };

  const handleChange = (step: number, values: Partial<FormValues>) => {
    setFormValues((prev) => ({ ...prev, ...values }));
  };

  const steps = [
    { id: 1, label: "Personal" },
    { id: 2, label: "Business" },
    { id: 3, label: "Services" },
    { id: 4, label: "Project" },
    { id: 5, label: "Submit" },
  ];

  return (
    <section id="application" className="py-16 bg-[hsl(var(--gray-light))]">
      <div className="container mx-auto px-4 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden"
        >
          <div className="p-8">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                {steps.map((step) => (
                  <div key={step.id} className="flex flex-col items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex-center font-semibold mb-2 ${
                        currentStep >= step.id ? "step-active" : "step-inactive"
                      }`}
                    >
                      {step.id}
                    </div>
                    <span className="text-sm font-medium">{step.label}</span>
                  </div>
                ))}
              </div>
              <div className="relative mt-2">
                <div className="absolute h-1 w-full bg-gray-200 rounded"></div>
                <div
                  className="absolute h-1 bg-primary rounded"
                  style={{ width: `${((currentStep - 1) / 4) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Form Steps */}
            {currentStep === 1 && (
              <PersonalForm 
                values={formValues} 
                onChange={(values) => handleChange(1, values)} 
                onNext={nextStep} 
              />
            )}
            {currentStep === 2 && (
              <BusinessForm 
                values={formValues} 
                onChange={(values) => handleChange(2, values)} 
                onNext={nextStep} 
                onPrev={prevStep} 
              />
            )}
            {currentStep === 3 && (
              <ServicesForm 
                values={formValues} 
                onChange={(values) => handleChange(3, values)} 
                onNext={nextStep} 
                onPrev={prevStep} 
              />
            )}
            {currentStep === 4 && (
              <ProjectForm 
                values={formValues} 
                onChange={(values) => handleChange(4, values)} 
                onNext={nextStep} 
                onPrev={prevStep} 
              />
            )}
            {currentStep === 5 && (
              <SubmitForm 
                values={formValues} 
                onSubmit={handleSubmit} 
                onPrev={prevStep} 
                isPending={submitApplication.isPending}
              />
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ApplicationForm;