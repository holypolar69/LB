import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FormValues } from "./ApplicationForm";

interface ServicesFormProps {
  values: FormValues;
  onChange: (values: Partial<FormValues>) => void;
  onNext: () => void;
  onPrev: () => void;
}

const serviceOptions = [
  { id: "ai-scaling", label: "AI-Powered Scaling" },
  { id: "web-design", label: "Web Design & Development" },
  { id: "digital-ads", label: "Digital Advertising" },
  { id: "analytics", label: "Analytics & Testing" },
  { id: "growth-strategy", label: "Growth Strategy Consulting" },
];

const budgetOptions = [
  "Under $5,000",
  "$5,000 - $10,000",
  "$10,000 - $25,000",
  "$25,000 - $50,000",
  "$50,000+"
];

const timelineOptions = [
  "Less than 1 month",
  "1-3 months",
  "3-6 months",
  "6-12 months",
  "1+ year"
];

const ServicesForm = ({ values, onChange, onNext, onPrev }: ServicesFormProps) => {
  const [errors, setErrors] = useState({
    services: "",
    budget: "",
    timeline: "",
  });

  const [isFormValid, setIsFormValid] = useState(false);

  const handleServicesChange = (serviceId: string, checked: boolean) => {
    let updatedServices;
    if (checked) {
      updatedServices = [...values.services, serviceId];
    } else {
      updatedServices = values.services.filter(id => id !== serviceId);
    }
    onChange({ services: updatedServices });
  };

  const handleSelectChange = (name: string, value: string) => {
    onChange({ [name]: value });
  };

  const validateForm = () => {
    const newErrors = {
      services: values.services.length === 0 ? "Please select at least one service" : "",
      budget: values.budget === "" ? "Please select a budget range" : "",
      timeline: values.timeline === "" ? "Please select a timeline" : "",
    };

    setErrors(newErrors);
    return !newErrors.services && !newErrors.budget && !newErrors.timeline;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onNext();
    }
  };

  useEffect(() => {
    // Re-validate whenever values change
    const isValid = 
      values.services.length > 0 && 
      values.budget !== "" && 
      values.timeline !== "";
    
    setIsFormValid(isValid);
  }, [values]);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h3 className="text-xl font-semibold mb-4">Services Information</h3>

      <div className="space-y-2">
        <Label>
          Services You're Interested In<span className="text-red-500">*</span>
        </Label>
        <div className="space-y-3">
          {serviceOptions.map((service) => (
            <div key={service.id} className="flex items-center space-x-2">
              <Checkbox
                id={service.id}
                checked={values.services.includes(service.id)}
                onCheckedChange={(checked) =>
                  handleServicesChange(service.id, checked as boolean)
                }
              />
              <Label htmlFor={service.id} className="cursor-pointer">
                {service.label}
              </Label>
            </div>
          ))}
        </div>
        {errors.services && <p className="text-sm text-red-500">{errors.services}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="budget">
          Budget Range<span className="text-red-500">*</span>
        </Label>
        <Select 
          value={values.budget} 
          onValueChange={(value) => handleSelectChange("budget", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select your budget range" />
          </SelectTrigger>
          <SelectContent>
            {budgetOptions.map((budget) => (
              <SelectItem key={budget} value={budget}>
                {budget}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.budget && <p className="text-sm text-red-500">{errors.budget}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="timeline">
          Project Timeline<span className="text-red-500">*</span>
        </Label>
        <Select 
          value={values.timeline} 
          onValueChange={(value) => handleSelectChange("timeline", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select your timeline" />
          </SelectTrigger>
          <SelectContent>
            {timelineOptions.map((timeline) => (
              <SelectItem key={timeline} value={timeline}>
                {timeline}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.timeline && <p className="text-sm text-red-500">{errors.timeline}</p>}
      </div>

      <div className="pt-4 flex justify-between">
        <Button type="button" variant="outline" onClick={onPrev}>
          Previous
        </Button>
        <Button type="submit" className="btn-primary">
          Next
        </Button>
      </div>
    </form>
  );
};

export default ServicesForm;
