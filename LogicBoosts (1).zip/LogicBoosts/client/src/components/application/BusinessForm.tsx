import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FormValues } from "./ApplicationForm";

interface BusinessFormProps {
  values: FormValues;
  onChange: (values: Partial<FormValues>) => void;
  onNext: () => void;
  onPrev: () => void;
}

const industries = [
  "Technology",
  "Healthcare",
  "Finance",
  "Education",
  "E-commerce",
  "Manufacturing",
  "Entertainment",
  "Food & Beverage",
  "Real Estate",
  "Other",
];

const companySizes = [
  "1-10 employees",
  "11-50 employees",
  "51-200 employees",
  "201-500 employees",
  "501-1000 employees",
  "1000+ employees",
];

const BusinessForm = ({ values, onChange, onNext, onPrev }: BusinessFormProps) => {
  const [errors, setErrors] = useState({
    companyName: "",
    website: "",
    industry: "",
    companySize: "",
  });

  const [isFormValid, setIsFormValid] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onChange({ [name]: value });
  };

  const handleSelectChange = (name: string, value: string) => {
    onChange({ [name]: value });
  };

  const validateForm = () => {
    const newErrors = {
      companyName: values.companyName.trim() === "" ? "Company name is required" : "",
      website: values.website.trim() === "" ? "Website is required" : "",
      industry: values.industry === "" ? "Please select an industry" : "",
      companySize: values.companySize === "" ? "Please select a company size" : "",
    };

    setErrors(newErrors);
    return !newErrors.companyName && !newErrors.website && !newErrors.industry && !newErrors.companySize;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onNext();
    }
  };

  useEffect(() => {
    // Re-validate whenever values change
    const isValid = 
      values.companyName.trim() !== "" && 
      values.website.trim() !== "" && 
      values.industry !== "" && 
      values.companySize !== "";
    
    setIsFormValid(isValid);
  }, [values]);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h3 className="text-xl font-semibold mb-4">Business Information</h3>

      <div className="space-y-2">
        <Label htmlFor="companyName">
          Company Name<span className="text-red-500">*</span>
        </Label>
        <Input
          id="companyName"
          name="companyName"
          value={values.companyName}
          onChange={handleChange}
          placeholder="Your company name"
          className="w-full"
          required
        />
        {errors.companyName && <p className="text-sm text-red-500">{errors.companyName}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="website">
          Website<span className="text-red-500">*</span>
        </Label>
        <Input
          id="website"
          name="website"
          value={values.website}
          onChange={handleChange}
          placeholder="https://yourcompany.com"
          className="w-full"
          required
        />
        {errors.website && <p className="text-sm text-red-500">{errors.website}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="industry">
          Industry<span className="text-red-500">*</span>
        </Label>
        <Select 
          value={values.industry} 
          onValueChange={(value) => handleSelectChange("industry", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select an industry" />
          </SelectTrigger>
          <SelectContent>
            {industries.map((industry) => (
              <SelectItem key={industry} value={industry}>
                {industry}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.industry && <p className="text-sm text-red-500">{errors.industry}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="companySize">
          Company Size<span className="text-red-500">*</span>
        </Label>
        <Select 
          value={values.companySize} 
          onValueChange={(value) => handleSelectChange("companySize", value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select company size" />
          </SelectTrigger>
          <SelectContent>
            {companySizes.map((size) => (
              <SelectItem key={size} value={size}>
                {size}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.companySize && <p className="text-sm text-red-500">{errors.companySize}</p>}
      </div>

      <div className="pt-4 flex justify-between">
        <Button type="button" variant="outline" onClick={onPrev}>
          Previous
        </Button>
        <Button type="submit" className="btn-primary">
          Next
        </Button>
      </div>
    </form>
  );
};

export default BusinessForm;
