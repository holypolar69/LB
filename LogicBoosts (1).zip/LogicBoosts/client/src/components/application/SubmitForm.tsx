import { Button } from "@/components/ui/button";
import { FormValues } from "./ApplicationForm";
import { Loader2 } from "lucide-react";

interface SubmitFormProps {
  values: FormValues;
  onSubmit: () => void;
  onPrev: () => void;
  isPending: boolean;
}

const SubmitForm = ({ values, onSubmit, onPrev, isPending }: SubmitFormProps) => {
  const formatServices = () => {
    const serviceMapping: Record<string, string> = {
      "ai-scaling": "AI-Powered Scaling",
      "web-design": "Web Design & Development",
      "digital-ads": "Digital Advertising",
      "analytics": "Analytics & Testing",
      "growth-strategy": "Growth Strategy Consulting",
    };
    
    return values.services.map(id => serviceMapping[id] || id).join(", ");
  };

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold mb-4">Review Your Application</h3>
      
      <div className="space-y-6">
        <div>
          <h4 className="font-semibold text-lg mb-2">Personal Information</h4>
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Full Name</p>
                <p className="font-medium">{values.fullName}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium">{values.email}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium">{values.phone || "Not provided"}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="font-semibold text-lg mb-2">Business Information</h4>
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Company Name</p>
                <p className="font-medium">{values.companyName}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Website</p>
                <p className="font-medium">{values.website}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Industry</p>
                <p className="font-medium">{values.industry}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Company Size</p>
                <p className="font-medium">{values.companySize}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="font-semibold text-lg mb-2">Services Information</h4>
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <p className="text-sm text-gray-500">Services Interested In</p>
                <p className="font-medium">{formatServices()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Budget Range</p>
                <p className="font-medium">{values.budget}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Project Timeline</p>
                <p className="font-medium">{values.timeline}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="font-semibold text-lg mb-2">Project Information</h4>
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">Project Description</p>
                <p className="font-medium">{values.projectDescription}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Business Goals</p>
                <p className="font-medium">{values.goals}</p>
              </div>
              {values.challenges && (
                <div>
                  <p className="text-sm text-gray-500">Current Challenges</p>
                  <p className="font-medium">{values.challenges}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="pt-4 flex justify-between">
        <Button type="button" variant="outline" onClick={onPrev} disabled={isPending}>
          Previous
        </Button>
        <Button 
          type="button" 
          className="btn-primary"
          onClick={onSubmit}
          disabled={isPending}
        >
          {isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : (
            "Submit Application"
          )}
        </Button>
      </div>
    </div>
  );
};

export default SubmitForm;
