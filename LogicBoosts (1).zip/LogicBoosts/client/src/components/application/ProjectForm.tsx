import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FormValues } from "./ApplicationForm";

interface ProjectFormProps {
  values: FormValues;
  onChange: (values: Partial<FormValues>) => void;
  onNext: () => void;
  onPrev: () => void;
}

const ProjectForm = ({ values, onChange, onNext, onPrev }: ProjectFormProps) => {
  const [errors, setErrors] = useState({
    projectDescription: "",
    goals: "",
  });

  const [isFormValid, setIsFormValid] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    onChange({ [name]: value });
  };

  const validateForm = () => {
    const newErrors = {
      projectDescription: values.projectDescription.trim().length < 10 
        ? "Please provide a more detailed description (at least 10 characters)" 
        : "",
      goals: values.goals.trim().length < 10 
        ? "Please provide more information about your goals (at least 10 characters)" 
        : "",
    };

    setErrors(newErrors);
    return !newErrors.projectDescription && !newErrors.goals;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onNext();
    }
  };

  useEffect(() => {
    // Re-validate whenever values change
    const isValid = 
      values.projectDescription.trim().length >= 10 && 
      values.goals.trim().length >= 10;
    
    setIsFormValid(isValid);
  }, [values]);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h3 className="text-xl font-semibold mb-4">Project Information</h3>

      <div className="space-y-2">
        <Label htmlFor="projectDescription">
          Project Description<span className="text-red-500">*</span>
        </Label>
        <Textarea
          id="projectDescription"
          name="projectDescription"
          value={values.projectDescription}
          onChange={handleChange}
          placeholder="Describe your project and what you're looking to accomplish"
          className="min-h-[100px]"
          required
        />
        {errors.projectDescription && (
          <p className="text-sm text-red-500">{errors.projectDescription}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="goals">
          Business Goals<span className="text-red-500">*</span>
        </Label>
        <Textarea
          id="goals"
          name="goals"
          value={values.goals}
          onChange={handleChange}
          placeholder="What specific goals are you trying to achieve with this project?"
          className="min-h-[100px]"
          required
        />
        {errors.goals && <p className="text-sm text-red-500">{errors.goals}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="challenges">Current Challenges (Optional)</Label>
        <Textarea
          id="challenges"
          name="challenges"
          value={values.challenges}
          onChange={handleChange}
          placeholder="What challenges are you currently facing that you'd like help overcoming?"
          className="min-h-[100px]"
        />
      </div>

      <div className="pt-4 flex justify-between">
        <Button type="button" variant="outline" onClick={onPrev}>
          Previous
        </Button>
        <Button type="submit" className="btn-primary">
          Next
        </Button>
      </div>
    </form>
  );
};

export default ProjectForm;
