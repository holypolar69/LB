import { Link } from "wouter";
import { motion } from "framer-motion";
import { Check } from "lucide-react";

const missionPoints = [
  {
    id: 1,
    text: "Eliminate guesswork from marketing",
  },
  {
    id: 2,
    text: "Replace broken funnels with fully-automated pipelines",
  },
  {
    id: 3,
    text: "Give every company a competitive edge with AI-enhanced growth strategies",
  },
  {
    id: 4,
    text: "Build beautiful, functional websites that don't just exist — they work",
  },
  {
    id: 5,
    text: "Bring high-level results to businesses without bloated agency pricing",
  },
];

const MissionSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section id="mission" className="py-16 bg-[hsl(var(--gray-light))]">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-8">Our Mission</h2>
            <p className="text-lg mb-12">
              To empower businesses with the tools, strategies, and systems they need to scale rapidly and intelligently in a digital world.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {missionPoints.map((point) => (
              <motion.div key={point.id} variants={itemVariants} className="mission-card">
                <div className="checkbox-circle mr-4">
                  <Check size={16} />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{point.text}</h3>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mt-10"
          >
            <Link href="/about" className="inline-flex items-center text-primary font-semibold hover:text-secondary transition-all">
              Learn more about our story
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-2"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                  clipRule="evenodd"
                />
              </svg>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default MissionSection;
