import { motion } from "framer-motion";
import { Link } from "wouter";

const CtaSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true, margin: "-100px" }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to grow your business?
          </h2>
          <p className="text-lg mb-10">
            Schedule a free consultation to discuss how our services can help you achieve your business goals.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/apply" className="btn-primary">
              Apply Now
            </Link>
            <Link
              href="/pricing"
              className="bg-white border border-gray-300 text-gray-dark hover:border-primary hover:text-primary font-semibold py-3 px-8 rounded-md transition-all"
            >
              View Pricing
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CtaSection;
