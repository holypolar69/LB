import { motion } from "framer-motion";
import { Link } from "wouter";

const features = [
  {
    id: 1,
    title: "Custom analytics dashboard setup",
    description: "Real-time insights into your business performance and growth metrics.",
  },
  {
    id: 2,
    title: "A/B testing implementation and management",
    description: "Optimize your website and campaigns with data-driven testing.",
  },
  {
    id: 3,
    title: "User behavior tracking and analysis",
    description: "Understand how users interact with your digital properties.",
  },
  {
    id: 4,
    title: "Conversion rate optimization",
    description: "Turn more visitors into customers with targeted improvements.",
  },
  {
    id: 5,
    title: "Custom reporting and insights",
    description: "Detailed reports tailored to your specific business goals.",
  },
  {
    id: 6,
    title: "Data-driven recommendations for growth",
    description: "Strategic advice based on real performance data.",
  },
];

const FeaturesSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section id="features" className="py-16 bg-[hsl(var(--gray-light))]">
      <div className="container mx-auto px-4 md:px-8">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-3xl md:text-4xl font-bold text-center mb-16"
        >
          What's Included
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.id}
              variants={itemVariants}
              className="feature-card"
            >
              <div className="flex-shrink-0 mr-4 bg-primary rounded-full h-10 w-10 flex items-center justify-center text-white font-bold">
                {feature.id}
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          viewport={{ once: true, margin: "-100px" }}
          className="flex justify-center mt-12 gap-4"
        >
          <Link href="/pricing" className="btn-primary">
            View pricing
          </Link>
          <Link href="/contact" className="btn-secondary">
            Contact us
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturesSection;
