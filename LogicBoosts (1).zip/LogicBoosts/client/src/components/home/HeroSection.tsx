import { Link } from "wouter";
import { motion } from "framer-motion";

const HeroSection = () => {
  return (
    <section id="home" className="gradient-bg text-white py-16 md:py-24">
      <div className="container mx-auto px-4 md:px-8">
        <motion.div 
          className="max-w-4xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Smart Growth Starts Here
          </h1>
          <p className="text-lg md:text-xl mb-10">
            LogicBoosts is a teen-led growth company using AI, web design, and digital strategy to scale modern brands.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/apply" className="btn-white">
              Get Your Free Growth Plan
            </Link>
            <Link href="/services" className="btn-outline">
              Explore Our Services
            </Link>
          </div>
        </motion.div>

        <motion.div 
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <div>
            <h3 className="font-bold text-xl mb-2">AI-Powered</h3>
            <p className="text-white/80">Growth Strategies</p>
          </div>
          <div>
            <h3 className="font-bold text-xl mb-2">Modern Design</h3>
            <p className="text-white/80">High-Converting Sites</p>
          </div>
          <div>
            <h3 className="font-bold text-xl mb-2">Results-Focused</h3>
            <p className="text-white/80">Data-Driven Campaigns</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
