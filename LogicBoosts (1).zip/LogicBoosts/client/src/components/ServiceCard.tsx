import { Link } from "wouter";
import { Check } from "lucide-react";
import { ReactNode } from "react";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  features: string[];
  id: string;
}

const ServiceCard = ({ title, description, icon, features, id }: ServiceCardProps) => {
  return (
    <div className="service-card">
      <div className="mb-4 bg-primary p-3 rounded-lg inline-block text-white">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <ul className="space-y-2 mb-6 flex-grow">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <Check className="text-primary mt-1 mr-2 h-4 w-4" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      <Link 
        href={`/services#${id}`} 
        className="inline-flex items-center text-primary font-semibold hover:text-secondary transition-all"
      >
        Learn more
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5 ml-2"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path
            fillRule="evenodd"
            d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
            clipRule="evenodd"
          />
        </svg>
      </Link>
    </div>
  );
};

export default ServiceCard;
