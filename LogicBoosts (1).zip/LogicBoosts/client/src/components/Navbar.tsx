import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, User, ChevronDown, Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import { useMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/use-auth";

const Navbar = () => {
  const [location] = useLocation();
  const isMobile = useMobile();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Placeholder for auth state
  const { isAuthenticated } = useAuth();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  // For demo purposes only - set logged in to true when visiting dashboard
  useEffect(() => {
    if (location.startsWith('/dashboard')) {
      setIsLoggedIn(true);
    }
  }, [location]);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const navLinks = [
    { path: "/", label: "Home" },
    { path: "/services", label: "Services" },
    { path: "/about", label: "About" },
    { path: "/pricing", label: "Pricing" },
  ];

  const navbarVariants = {
    hidden: { opacity: 0, y: -25 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.3,
        staggerChildren: 0.05
      }
    }
  };

  const linkVariants = {
    hidden: { opacity: 0, y: -10 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.header 
      initial="hidden"
      animate="visible"
      variants={navbarVariants}
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-300",
        isScrolled ? "bg-white/95 backdrop-blur-sm shadow-md" : "bg-white"
      )}
    >
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/">
            <motion.div 
              className="flex items-center" 
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary text-transparent bg-clip-text">LB</span>
              <span className="ml-2 text-xl font-semibold">LogicBoosts</span>
            </motion.div>
          </Link>

          {/* Desktop Navigation */}
          {!isMobile && (
            <motion.nav className="flex items-center space-x-8" variants={navbarVariants}>
              {navLinks.map((link) => (
                <motion.div key={link.path} variants={linkVariants}>
                  <Link
                    href={link.path}
                    className={cn(
                      "text-gray-dark hover:text-primary font-medium transition-all",
                      location === link.path && "text-primary font-semibold"
                    )}
                  >
                    {link.label}
                  </Link>
                </motion.div>
              ))}
              
              <motion.div variants={linkVariants}>
                <Link href="/contact">
                  <Button variant="ghost" className="font-medium hover:text-primary hover:bg-primary/10">Contact</Button>
                </Link>
              </motion.div>
              
              <motion.div variants={linkVariants}>
                <Link href="/apply">
                  <div className="motion-button">
                  <Button 
                    className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-white font-semibold"
                  >
                    Apply Now
                  </Button>
                </div>
                </Link>
              </motion.div>
              
              {/* Discrete admin button */}
              <motion.div variants={linkVariants} className="text-gray-300">
                {isAuthenticated ? (
                  <Link href="/dashboard">
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
                      <Lock size={16} className="mr-1" />
                      Admin
                    </Button>
                  </Link>
                ) : (
                  <Link href="/admin/login">
                    <Button variant="ghost" size="sm" className="text-gray-300 hover:text-gray-500">
                      <Lock size={16} />
                    </Button>
                  </Link>
                )}
              </motion.div>
              
              {isLoggedIn && (
                <motion.div variants={linkVariants}>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="flex items-center gap-2">
                        <User size={18} />
                        <span>Account</span>
                        <ChevronDown size={14} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard" className="cursor-pointer">Dashboard</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard/projects" className="cursor-pointer">Projects</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard/settings" className="cursor-pointer">Settings</Link>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </motion.div>
              )}
            </motion.nav>
          )}

          {/* Mobile Menu Toggle */}
          {isMobile && (
            <motion.button
              whileTap={{ scale: 0.95 }}
              className="text-gray-dark focus:outline-none"
              onClick={toggleMenu}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </motion.button>
          )}
        </div>

        {/* Mobile Navigation Menu */}
        <AnimatePresence>
          {isMobile && isMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="py-4 space-y-4 bg-white overflow-hidden"
            >
              {navLinks.map((link, index) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link
                    href={link.path}
                    className={cn(
                      "block text-gray-dark hover:text-primary font-medium px-4 py-2 transition-all",
                      location === link.path && "text-primary font-semibold"
                    )}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {link.label}
                  </Link>
                </motion.div>
              ))}
              
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: navLinks.length * 0.1 }}
              >
                <Link 
                  href="/contact" 
                  onClick={() => setIsMenuOpen(false)}
                  className="block px-4 py-2"
                >
                  <Button variant="ghost" className="w-full justify-start">Contact</Button>
                </Link>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: (navLinks.length + 1) * 0.1 }}
              >
                <Link 
                  href="/apply" 
                  onClick={() => setIsMenuOpen(false)}
                  className="block px-4 py-2"
                >
                  <Button className="w-full bg-gradient-to-r from-primary to-secondary text-white">Apply Now</Button>
                </Link>
              </motion.div>
              
              {/* Admin access in mobile menu */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: (navLinks.length + 1.5) * 0.1 }}
                className="px-4 py-2 flex justify-end"
              >
                {isAuthenticated ? (
                  <Link 
                    href="/dashboard" 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-gray-400 hover:text-gray-600 flex items-center"
                  >
                    <Lock size={16} className="mr-2" />
                    Admin Dashboard
                  </Link>
                ) : (
                  <Link 
                    href="/admin/login" 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-gray-300 hover:text-gray-500"
                    aria-label="Admin Access"
                  >
                    <Lock size={16} />
                  </Link>
                )}
              </motion.div>
              
              {isLoggedIn && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: (navLinks.length + 2) * 0.1 }}
                >
                  <div className="px-4 py-2">
                    <div className="font-medium text-gray-600 mb-2">Account</div>
                    <Link 
                      href="/dashboard" 
                      onClick={() => setIsMenuOpen(false)}
                      className="block py-2 pl-4 text-gray-dark hover:text-primary"
                    >
                      Dashboard
                    </Link>
                    <Link 
                      href="/dashboard/projects" 
                      onClick={() => setIsMenuOpen(false)}
                      className="block py-2 pl-4 text-gray-dark hover:text-primary"
                    >
                      Projects
                    </Link>
                    <Link 
                      href="/dashboard/settings" 
                      onClick={() => setIsMenuOpen(false)}
                      className="block py-2 pl-4 text-gray-dark hover:text-primary"
                    >
                      Settings
                    </Link>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
};

export default Navbar;
