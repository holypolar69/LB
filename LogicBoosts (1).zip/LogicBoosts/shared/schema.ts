import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table (keeping the existing users table)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Contact form submissions
export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  responded: boolean("responded").default(false),
});

export const insertContactSchema = createInsertSchema(contactSubmissions, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  email: (schema) => schema.email("Please enter a valid email address"),
  subject: (schema) => schema.min(2, "Subject is required"),
  message: (schema) => schema.min(10, "Message must be at least 10 characters")
});

export type InsertContact = z.infer<typeof insertContactSchema>;
export type ContactSubmission = typeof contactSubmissions.$inferSelect;

// Service applications
export const serviceApplications = pgTable("service_applications", {
  id: serial("id").primaryKey(),
  // Personal information
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  
  // Business information
  companyName: text("company_name").notNull(),
  website: text("website").notNull(),
  industry: text("industry").notNull(),
  companySize: text("company_size").notNull(),
  
  // Services information - stored as JSON
  services: jsonb("services").notNull().$type<string[]>(),
  budget: text("budget").notNull(),
  timeline: text("timeline").notNull(),
  
  // Project information
  projectDescription: text("project_description").notNull(),
  goals: text("goals").notNull(),
  challenges: text("challenges"),
  
  // Status tracking
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertApplicationSchema = createInsertSchema(serviceApplications, {
  fullName: (schema) => schema.min(2, "Full name is required"),
  email: (schema) => schema.email("Please enter a valid email address"),
  companyName: (schema) => schema.min(2, "Company name is required"),
  website: (schema) => schema.min(3, "Website is required"),
  industry: (schema) => schema.min(2, "Industry is required"),
  companySize: (schema) => schema.min(2, "Company size is required"),
  projectDescription: (schema) => schema.min(10, "Project description must be at least 10 characters"),
  goals: (schema) => schema.min(10, "Goals must be at least 10 characters")
});

export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type ServiceApplication = typeof serviceApplications.$inferSelect;
